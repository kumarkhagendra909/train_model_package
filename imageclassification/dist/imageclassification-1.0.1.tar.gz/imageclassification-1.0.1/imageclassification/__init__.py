# __init__ file for this image classification project.

# attribute for version check 
__version__ = "1.0.0"
